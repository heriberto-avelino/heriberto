from django.urls import path
from . import views

urlpatterns = [
    # /register/volunteer
    path('volunteer', views.get_volunteer, name="get_volunteer"),
    # /register/request
    path('request', views.get_request, name="get_request"),
    # /register/gracias
    path('gracias', views.get_gracias, name='get_gracias'),
    # /register/solicitudenviada
    path('solicitudenviada', views.get_solicitud_enviada, name='get_solicitud_enviada'),
]