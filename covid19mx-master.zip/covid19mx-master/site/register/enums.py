from enum import Enum

# TODO: Which set of fields makes sense here?
class KnowledgeField(Enum):
    KF1 = "A"
    KF2 = "B"
    KF3 = "C"
    KF4 = "D"
    KF5 = "E"

    @classmethod
    def get_choices(c):
        return tuple((kf.name, kf.value) for kf in c)

class States(Enum):
    AGUASCALIENTES          = 1
    BAJA_CALIFORNIA         = 2
    BAJA_CALIFORNIA_SUR     = 3
    CAMPECHE                = 4
    CHIAPAS                 = 5
    CHIHUAHUA               = 6
    CIUDAD_DE_MEXICO        = 7
    COAHUILA                = 8
    COLIMA                  = 9
    DURANGO                 = 10
    # TODO: Add the other states
    
class Form(Enum):
    REQUEST     = 0
    VOLUNTEER   = 1