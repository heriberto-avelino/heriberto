from django.db import models
from . import enums

class Volunteer(models.Model):
    name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    institution = models.CharField(max_length=200, blank=True)
    knowledge_field = models.CharField(
        max_length=3,
        choices=[(kf.name, kf.value) for kf in enums.KnowledgeField])
    email = models.EmailField(max_length=254)
    available_hours_per_week = models.IntegerField(default=5)
    state = models.IntegerField(
        choices=[(s, str(s)) for s in enums.States], blank=True)

class Request(models.Model):
    name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    institution = models.CharField(max_length=200)
    occupation = models.CharField(max_length=100)
    person_in_charge = models.CharField(max_length=200)
    email = models.EmailField(max_length=254)
    website = models.URLField(max_length=300, blank=True)
    seeking_kf = models.CharField(
        max_length=3,
        choices=[(kf.name, kf.value) for kf in enums.KnowledgeField])
    weekly_time_commitment = models.IntegerField()
    project_description = models.TextField(max_length=280)
    # TODO: Add option to specify the location where the collaboration is needed
    # this'd be helpful if the work cannot be achieved remotely.