from django.forms import ModelForm
from . import enums
from .models import Request, Volunteer

class VolunteerForm(ModelForm):
    class Meta:
        model = Volunteer
        fields = [
            'name',
            'last_name',
            'institution',
            'knowledge_field',
            'email',
            'available_hours_per_week',
            'state',
        ]

class RequestForm(ModelForm):
    class Meta:
        model = Request
        fields = [
            'name',
            'last_name',
            'institution',
            'occupation',
            'person_in_charge',
            'email',
            'website',
            'seeking_kf',
            'weekly_time_commitment',
            'project_description',
        ]