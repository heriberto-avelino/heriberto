from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.template import loader
from django.utils import timezone

from .models import Request, Volunteer
from .forms import RequestForm, VolunteerForm
from . import enums

# TODO: Refactor these two methods into three to reuse code.
# TODO: We should display a friendly error message in case something goes wrong.

def get_volunteer(request):
    if request.method == 'POST':
        form = VolunteerForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('gracias')
    else:
        form = VolunteerForm()

    template = loader.get_template('register/volunteer.html')
    context = {
        'form': form,
    }

    return HttpResponse(template.render(context, request))

def get_request(request):
    if request.method == 'POST':
        form = RequestForm(request.POST)
        if form.is_valid():
            # TODO: After submitting the request, we should maybe
            # and further validation that it is legit, and then
            # send out an email to all volunteers that match the
            # request.
            form.save()
            return HttpResponseRedirect('solicitudenviada')
    else:
        form = RequestForm()

    template = loader.get_template('register/request.html')
    context = {
        'form' : form,
    }

    return HttpResponse(template.render(context, request))

# TODO: Both methods bellow should probably make use of statics
# and a simple redirection to the main page.
def get_gracias(request):
    return HttpResponse("Gracias por registrarte como voluntarix")

# TODO
def get_solicitud_enviada(request):
    return HttpResponse("Tu solicitud ha sido enviada")